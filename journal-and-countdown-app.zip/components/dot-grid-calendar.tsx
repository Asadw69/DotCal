"use client"

import { useState } from "react"
import { format, differenceInDays } from "date-fns"

interface DotGridCalendarProps {
  entryMap: Map<string, { id: string; content: string }>
  onDayClick: (dateStr: string) => void
  loading: boolean
}

export default function DotGridCalendar({ entryMap, onDayClick, loading }: DotGridCalendarProps) {
  const [hoveredDate, setHoveredDate] = useState<string | null>(null)

  // Calculate year range
  const yearStart = new Date(2026, 0, 1)
  const yearEnd = new Date(2026, 11, 31)
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  // Calculate days remaining
  const daysRemaining = differenceInDays(yearEnd, today)
  const daysElapsed = 365 - daysRemaining

  // Generate all days in the year
  const allDays = []
  const currentDate = new Date(yearStart)
  while (currentDate <= yearEnd) {
    allDays.push(new Date(currentDate))
    currentDate.setDate(currentDate.getDate() + 1)
  }

  // Get today's memory if it exists
  const todayStr = format(today, "yyyy-MM-dd")
  const todayEntry = entryMap.get(todayStr)

  return (
    <div className="space-y-6">
      {/* Header - iOS Bubble Container */}
      <div className="rounded-3xl bg-gradient-to-b from-accent to-card border border-border/50 p-8 backdrop-blur-md">
        <div className="space-y-2 text-center">
          <div className="text-4xl font-light tracking-tight">{daysRemaining}</div>
          <p className="text-sm text-muted-foreground">days left in 2026</p>
          {todayEntry && (
            <div className="flex items-center justify-center gap-2 mt-4 text-xs text-muted-foreground">
              <span className="inline-block w-4 h-4 rounded-full bg-primary/30"></span>
              today's memory
            </div>
          )}
        </div>
      </div>

      {/* Dot Grid - iOS Bubble Container */}
      <div className="rounded-3xl bg-gradient-to-b from-accent to-card border border-border/50 p-6 backdrop-blur-md">
        <div className="grid gap-2.5">
          {/* 7 columns for weeks */}
          <div
            className="grid gap-1.5"
            style={{
              gridTemplateColumns: "repeat(7, 1fr)",
              gridAutoRows: "auto",
            }}
          >
            {allDays.map((day, index) => {
              const dateStr = format(day, "yyyy-MM-dd")
              const hasEntry = entryMap.has(dateStr)
              const isPastOrToday = day <= today
              const isToday = day.toDateString() === today.toDateString()

              return (
                <button
                  key={index}
                  onClick={() => {
                    if (isPastOrToday) {
                      onDayClick(dateStr)
                    }
                  }}
                  onMouseEnter={() => setHoveredDate(dateStr)}
                  onMouseLeave={() => setHoveredDate(null)}
                  disabled={!isPastOrToday}
                  className={`
                    w-full aspect-square rounded-full transition-all duration-200
                    flex items-center justify-center relative
                    ${isToday ? "ring-2 ring-offset-2 ring-primary" : ""}
                    ${
                      hasEntry
                        ? "bg-primary text-primary-foreground shadow-md hover:shadow-lg hover:scale-110 cursor-pointer"
                        : isPastOrToday
                          ? "bg-muted hover:bg-muted/80 text-muted-foreground hover:scale-110 cursor-pointer"
                          : "bg-muted/50 text-muted-foreground/40 cursor-default opacity-50"
                    }
                  `}
                  title={`${format(day, "MMM d, yyyy")}`}
                >
                  {/* Dot visualization */}
                  <div
                    className={`w-2 h-2 rounded-full transition-all ${
                      hasEntry ? "bg-primary-foreground scale-100" : "bg-foreground/20 scale-75"
                    }`}
                  ></div>
                </button>
              )
            })}
          </div>
        </div>

        {/* Footer Stats */}
        <div className="mt-6 pt-4 border-t border-border/30 flex justify-between text-xs text-muted-foreground">
          <div>
            <div className="font-medium">{daysElapsed}</div>
            <div>days passed</div>
          </div>
          <div className="text-right">
            <div className="font-medium">{entryMap.size}</div>
            <div>entries</div>
          </div>
          <div className="text-right">
            <div className="font-medium">{Math.round((entryMap.size / 365) * 100)}%</div>
            <div>complete</div>
          </div>
        </div>
      </div>
    </div>
  )
}
